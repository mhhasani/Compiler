// This program calculates the sum of two numbers (first@gmail.com)
/*
    in this program we will learn how to use variables
    by second@gmail.com
 */
let num1 = 5;
let num2 = 10;
let sum = num1 + num2;

let email = "third@gmail.com";

console.log("The sum of " + num1 + " and " + num2 + " is " + sum);
