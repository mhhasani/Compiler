public class MyClass {
    public void SampleFunction1() {

    }
    private void SampleFunction2() {
        
    }
    private void SampleFunction2() {
        print(2);
    }
}
