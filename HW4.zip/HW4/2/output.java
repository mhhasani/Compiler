 class MyClass {
    public void SampleFunction1() {throw new UnsupportedOperationException();}

    
    private void SampleFunction2() {throw new UnsupportedOperationException();}
        
    
    private void SampleFunction2() {
        print(2);
    }
}
