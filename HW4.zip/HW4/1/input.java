public class Sample {
    private int id;
    private String name;
    private double salary;
    private final LocalDate hireDate;
    private List<String> skills;
}